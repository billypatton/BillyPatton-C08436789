﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameManager : MonoBehaviour {
	public int NumberOfBots = 5;
	public int NummberOfAmmoBoxes = 10;

	public GameObject bot;
	public GameObject ammo;

	List<GameObject> botList = new List<GameObject>();
	List<GameObject> ammoList = new List<GameObject> ();
	

	void Start () { 

		for (int i = 0; i < NumberOfBots; i++) 
			{
				GameObject botClone = Instantiate(bot, transform.position, transform.rotation) as GameObject;
				botList.Add (botClone);
			}

		for (int i = 0; i < NummberOfAmmoBoxes; i++) 
			{
				GameObject ammoClone = Instantiate(ammo, transform.position, transform.rotation) as GameObject;
				ammoList.Add (ammoClone);
			}

		GameObject[] AllEnemies = GameObject.FindGameObjectsWithTag ("bot");

			foreach (GameObject bot in botList) 
				{
					GameObject ThisEnemy = AllEnemies[Random.Range(0, 4)];

					if(ThisEnemy == bot)
					{
						ThisEnemy = AllEnemies[Random.Range(0, 4)]; 
					}

					bot.GetComponent<StateMachine>().SwitchState(new PatrolState(bot, ThisEnemy));
			
				}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
