﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {

	public GameObject Bots;
	public GameObject otherbots;
	//static public Vector3 RandomPos1 = new Vector3 (Random.Range (-20, 20), Random.Range (-20, 20), Random.Range (-20, 20));
	// Use this for initialization
	void Start () {



		for (int i = 0; i < 5; i++) 
		{
			Vector3 RandomPos = new Vector3 (Random.Range (-20, 20), Random.Range (-20, 20), Random.Range (-20, 20));
			Instantiate(Bots,RandomPos,Quaternion.identity);
			//Bots.GetComponent<StateMachine>().SwitchState(new IdleState(Bots));
		}

		otherbots = GameObject.FindGameObjectWithTag("bot");

		Bots.GetComponent<StateMachine>().SwitchState(new IdleState(Bots,otherbots));
       
        
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
