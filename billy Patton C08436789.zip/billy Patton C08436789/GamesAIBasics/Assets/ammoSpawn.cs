﻿using UnityEngine;
using System.Collections;

public class ammoSpawn : MonoBehaviour {


	public GameObject AmmoPickUp;

	// Use this for initialization
	void Start () 
	{
		for (int i = 0; i < 10; i++) 
		{
			Vector3 RandomPos = new Vector3 (Random.Range (-20, 20), Random.Range (-20, 20), Random.Range (-20, 20));
			Instantiate(AmmoPickUp,RandomPos,Quaternion.identity);
			//AmmoPickUp.renderer.material.color = Color.red;
			//gameObject.tag = "ammo";
		}
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}


}
