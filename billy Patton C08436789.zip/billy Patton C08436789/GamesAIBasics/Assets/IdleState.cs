﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class IdleState:State
{
    static Vector3 initialPos = Vector3.zero;
	 //Vector3 RandomPos = new Vector3 (Random.Range (-20, 20), Random.Range (-20, 20), Random.Range (-20, 20) );
//	float posX = UnityEngine.Random.Range(-10,10);
//	float posY = UnityEngine.Random.Range(-10,10);
//	float posZ = UnityEngine.Random.Range(-10,10);

    GameObject bot;

    public override string Description()
    {
        return "Idle State";
    }

    public IdleState(GameObject bot,GameObject otherbots)
        : base(bot)
    {
        this.bot = bot;
    }

    public override void Enter()
    {

		float posX = UnityEngine.Random.Range(-20,20);
		float posY = UnityEngine.Random.Range(-20,20);
		float posZ = UnityEngine.Random.Range(-20,20);
		float posX1 = UnityEngine.Random.Range(-20,20);
		float posY1 = UnityEngine.Random.Range(-20,20);
		float posZ1 = UnityEngine.Random.Range(-20,20);
		
		myGameObject.GetComponent<SteeringBehaviours>().path.Waypoints.Add(new Vector3(posX,0,posZ));
		bot.GetComponent<SteeringBehaviours>().path.Waypoints.Add(new Vector3(posX,0,posZ));
		//myGameObject.GetComponent<SteeringBehaviours>().path.Waypoints.Add(new Vector3(posX1,0,posZ1));
//			myGameObject.GetComponent<SteeringBehaviours>().path.Waypoints.Add(new Vector3(posX,0,posZ));
//			myGameObject.GetComponent<SteeringBehaviours>().path.Waypoints.Add(new Vector3(posX1,0,posZ1));


		myGameObject.GetComponent<SteeringBehaviours>().path.Looped = true;            
        myGameObject.GetComponent<SteeringBehaviours>().path.draw = true;
        myGameObject.GetComponent<SteeringBehaviours>().TurnOffAll();
        myGameObject.GetComponent<SteeringBehaviours>().FollowPathEnabled = true;
    }
    public override void Exit()
    {
        myGameObject.GetComponent<SteeringBehaviours>().path.Waypoints.Clear();
    }

    public override void Update()
    {


//
//        float range = 5.0f;           
//        // Can I see the enemy?
//        if ((enemyGameObject.transform.position - myGameObject.transform.position).magnitude < range)
//        {
//            // Is the leader inside my FOV
//            myGameObject.GetComponent<StateMachine>().SwitchState(new AttackingState(myGameObject, enemyGameObject));
//        }
    }
}
