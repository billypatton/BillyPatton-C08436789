﻿using UnityEngine;
using System.Collections;

public class Bots : MonoBehaviour {

	static public int health = 10;
	 public int ammo = 10;
	public GameObject target;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{
	
		if (ammo <= 0) 
		{
			SeekAmmo();
		}

		if (health <= 0) 
		{
			Destroy (this.gameObject)	;
		}
	}

	void SeekAmmo()
	{
		target = GameObject.FindGameObjectWithTag("ammo");
		transform.position = target.transform.position;
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.tag == "ammo") 
		{
			ammo = 10;
		}
	}

}
